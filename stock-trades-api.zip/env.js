module.exports = {
    mode: 'development',
    // mode: 'production'
};

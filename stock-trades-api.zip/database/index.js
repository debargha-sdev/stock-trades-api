exports.connect = require('./connector').connect;
exports.seeder = require('./seeders');